from gestio_partides import generar_lliga, desar_partides_a_fitxer
from puntuacions import actualitzar_puntuacions, carregar_puntuacions

def inicialitzar_sessio(sessio):
    if 'mode_torneig' not in sessio:# Si no hi ha mode de torneig, creem 'lliga'
        sessio['mode_torneig'] = 'lliga'
    if sessio.get('mode_torneig', 'lliga') == 'lliga' and 'jornada_actual' not in sessio:
        sessio['jornada_actual'] = 0
    if 'partides' not in sessio:# Si no hi ha partides, creem una llista buida
        sessio['partides'] = []

def generar_i_desar_partides(sessio, participants, fitxer, mode):
    if len(participants) < 2:
        return "Es necessiten mínim 2 participants" 
    sessio['mode_torneig'] = mode
    if mode == 'lliga':
        sessio['partides'] = list(generar_lliga(participants)) 
        sessio['jornada_actual'] = 0
    elif mode == 'eliminatòries':
        import random
        random.shuffle(participants)
        round1 = list(zip(participants[::2], participants[1::2]))
        sessio['partides'] = round1  # Guardem només la ronda actual
        sessio['jornada_actual'] = None
    desar_partides_a_fitxer(sessio['partides'], fitxer)
    return None

def processar_jornada(sessio, puntuacions_fitxer, form_data):
    mode = sessio.get('mode_torneig', 'lliga')
    if mode == 'lliga':
        puntuacions = carregar_puntuacions(puntuacions_fitxer)
        current_jornada = sessio.get('jornada_actual', 0)
        partides = sessio.get('partides', [])
        if not partides or current_jornada >= len(partides):
            return "No hi ha més jornades"
        resultats = {k: v for k, v in form_data.items() if k.startswith('partida_')}
        if len(resultats) < len(partides[current_jornada]):
            return "Selecciona un guanyador per a totes les partides"
        for guanyador in resultats.values():
            actualitzar_puntuacions(puntuacions, guanyador)
        with open(puntuacions_fitxer, 'w') as f:
            for nom, punts in puntuacions.items():
                f.write(f"{nom}:{punts}\n")
        if current_jornada < len(partides) - 1:
            sessio['jornada_actual'] = current_jornada + 1
        else:
            return "Felicitats! El torneig ha finalitzat! Consulta les puntuacions."
        return None
    elif mode == 'eliminatòries':
        current_round = sessio.get('partides', [])
        resultats = [v for k, v in form_data.items() if k.startswith('partida_')]
        if len(resultats) < len(current_round):
            return "Selecciona un guanyador per a totes les partides"
        puntuacions = carregar_puntuacions(puntuacions_fitxer)
        for winner in resultats:
            actualitzar_puntuacions(puntuacions, winner)
        with open(puntuacions_fitxer, 'w') as f:
            for nom, punts in puntuacions.items():
                f.write(f"{nom}:{punts}\n")
        if len(resultats) == 1:
            sessio['partides'] = []
            return "Felicitats! El torneig ha finalitzat! Consulta les puntuacions."
        else:
            import random
            random.shuffle(resultats)
            new_round = list(zip(resultats[::2], resultats[1::2]))
            sessio['partides'] = new_round
            return None

def reiniciar_fitxers(fitxers):
    for fitxer in fitxers:
        with open(fitxer, 'w') as f:
            f.truncate(0)