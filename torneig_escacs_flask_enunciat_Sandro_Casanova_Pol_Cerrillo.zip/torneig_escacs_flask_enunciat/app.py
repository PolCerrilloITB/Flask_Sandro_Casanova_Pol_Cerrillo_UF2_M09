from flask import Flask, render_template, request, redirect, url_for, session
from gestio_participants import afegir_participant, carregar_participants_de_fitxer, eliminar_participant
from gestio_partides import generar_lliga, generar_eliminatòries, desar_partides_a_fitxer
from puntuacions import actualitzar_puntuacions, calcular_ranquing, carregar_puntuacions as carregar_puntuacions_module
from utils import (
    inicialitzar_sessio,
    generar_i_desar_partides,
    processar_jornada,
    reiniciar_fitxers
)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey123'

# Fitxers de configuració
PARTICIPANTS_FITXER = 'participants.txt'
PARTIDES_FITXER = 'partides.txt'
PUNTUACIONS_FITXER = 'puntuacions.txt'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/participants', methods=['GET', 'POST'])
def gestionar_participants():
    missatge = None
    if request.method == 'POST':
        if 'nom' in request.form and request.form['nom'].strip() != "":
            nom = request.form['nom'].strip()
            # Validem que el nom tingui almenys 2 caràcters i només lletres i espais
            if nom and len(nom) >= 2 and nom.replace(" ", "").isalpha():
                if afegir_participant(nom, PARTICIPANTS_FITXER):
                    missatge = f"{nom} afegit correctament!"
                else:
                    missatge = "Aquest participant ja existeix"
            else:
                missatge = "Nom invàlid"
        elif 'eliminar' in request.form:
            nom = request.form['eliminar']
            if eliminar_participant(nom, PARTICIPANTS_FITXER):
                missatge = f"Participant {nom} eliminat."
            else:
                missatge = f"No s'ha pogut eliminar {nom}."
    participants = carregar_participants_de_fitxer(PARTICIPANTS_FITXER)
    return render_template('participants.html', participants=participants, missatge=missatge)

@app.route('/partides', methods=['GET', 'POST'])
def gestionar_partides():
    inicialitzar_sessio(session)
    participants = carregar_participants_de_fitxer(PARTICIPANTS_FITXER)
    missatge = None

    if request.method == 'POST':
        if 'generar_partides' in request.form:
            mode = request.form.get('mode', 'lliga')
            missatge = generar_i_desar_partides(session, participants, PARTIDES_FITXER, mode)
        elif 'avançar_jornada' in request.form:
            missatge = processar_jornada(session, PUNTUACIONS_FITXER, request.form)

    mode = session.get('mode_torneig', 'lliga')
    if mode == 'lliga':
        partides_jornada = session.get('partides', [])
        jornada_actual = session.get('jornada_actual', 0)
        if partides_jornada and jornada_actual < len(partides_jornada):
            partides_actuals = partides_jornada[jornada_actual]
        else:
            partides_actuals = []
        total_jornades = len(partides_jornada)
    else:  # Mode eliminatòries
        partides_actuals = session.get('partides', [])
        jornada_actual = None
        total_jornades = None

    return render_template('partides.html',
                           partides=partides_actuals,
                           jornada_actual=jornada_actual,
                           total_jornades=total_jornades,
                           mode=mode,
                           missatge=missatge)

@app.route('/puntuacions')
def mostrar_puntuacions():
    puntuacions = carregar_puntuacions_module(PUNTUACIONS_FITXER)
    ranking = calcular_ranquing(puntuacions)
    return render_template('puntuacions.html', ranking=ranking)

@app.route('/reiniciar')
def reiniciar_torneig():
    reiniciar_fitxers([PUNTUACIONS_FITXER, PARTIDES_FITXER, PARTICIPANTS_FITXER])
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)