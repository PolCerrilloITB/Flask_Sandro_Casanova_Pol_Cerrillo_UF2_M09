from itertools import combinations
import random

def generar_lliga(participants):
    partides = []
    num_participants = len(participants)
    
    # Crear un calendari rodó de lliga (Round Robin)
    for i in range(num_participants - 1):
        jornada = []
        for j in range(num_participants // 2):
            jugador1 = participants[j]
            jugador2 = participants[num_participants - j - 1]
            jornada.append((jugador1, jugador2))
        partides.append(jornada)
        
        # Rotar els participants per a la següent jornada
        participants.insert(1, participants.pop())

    return partides

def generar_eliminatòries(participants):
    """
    Aquesta funció ja no s'utilitza per al mode eliminatòries, ja que ara
    generem la primera ronda directament a 'generar_i_desar_partides'.
    """
    # Fer llista aleatoria de jornades
    random.shuffle(participants)
    rondes = []
    while len(participants) > 1:
        ronda = list(zip(participants[::2], participants[1::2]))
        rondes.append(ronda)
        participants = [f"Guanyador de {p1} vs {p2}" for p1, p2 in ronda]
    return rondes
# Guardar partides al fitxer
def desar_partides_a_fitxer(partides, fitxer):
    with open(fitxer, 'w') as f:
        if partides:
            if isinstance(partides[0], tuple):
                for partida in partides:
                    f.write(f"{partida[0]},{partida[1]}\n")
            else:
                for ronda in partides:
                    for partida in ronda:
                        f.write(f"{partida[0]},{partida[1]}\n")
                    f.write("\n")
        else:
            f.write("")
            
def carregar_partides_de_fitxer(fitxer):
    try:
        with open(fitxer, 'r') as f:
            matches = [line.strip().split(',') for line in f if line.strip() != '']
            return [tuple(match) for match in matches]
    except FileNotFoundError:
        return []